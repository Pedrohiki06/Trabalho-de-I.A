import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from streamlit.testing.v1 import AppTest


def test_app_runs_demo():
    at = AppTest.from_file(str(Path(__file__).resolve().parents[1] / "app.py"), default_timeout=120).run()
    assert not at.exception, at.exception
    assert len(at.metric) == 4
    assert len(at.tabs) == 4
    print([m.value for m in at.metric])


if __name__ == "__main__":
    test_app_runs_demo()
    print("ok")
