"""Demo da PoC. Executar: streamlit run app.py"""
import pandas as pd
import plotly.express as px
import streamlit as st
import pipeline

def brl(v):
    return "R$ " + f"{v:,.0f}".replace(",", ".")


st.set_page_config(page_title="FinIA — hábitos financeiros", page_icon="💸", layout="wide")
st.title("💸 FinIA — análise inteligente de hábitos financeiros")
st.caption("PoC acadêmica (SIN 323 · UFV). Não é aconselhamento financeiro. Os dados enviados são processados localmente nesta sessão.")


@st.cache_resource
def _model():
    return pipeline.get_model()


with st.sidebar:
    st.header("Dados")
    up = st.file_uploader("Extrato (CSV: data, descrição, valor)", type=["csv"])
    use_demo = st.checkbox("Usar extrato de exemplo (sintético)", value=up is None)
    contam = st.slider("Sensibilidade do detector de anomalias", 0.01, 0.10, 0.04, 0.01,
                       help="Fração esperada de transações atípicas. Maior = mais alertas e mais falsos positivos.")
    st.markdown("**Formato:** valores negativos = despesas, positivos = receitas.")

try:
    if up is not None:
        raw = pipeline.load_statement(up)
    elif use_demo:
        raw = pipeline.load_statement(pipeline.ROOT / "data" / "exemplo_extrato.csv")
    else:
        st.info("Envie um CSV ou use o exemplo.")
        st.stop()
except Exception as e:  # noqa: BLE001
    st.error(f"Não consegui ler o arquivo: {e}")
    st.stop()

res = pipeline.run(raw, _model(), contamination=contam)
d, k = res["df"], res["kpis"]

c1, c2, c3, c4 = st.columns(4)
c1.metric("Receita média/mês", brl(k["receita_media"]))
c2.metric("Despesa média/mês", brl(k["despesa_media"]))
c3.metric("Taxa de poupança", f"{k['taxa_poupanca']*100:.0f}%" if k["taxa_poupanca"] == k["taxa_poupanca"] else "—")
c4.metric("Meses analisados", k["meses"])

tab1, tab2, tab3, tab4 = st.tabs(["Recomendações", "Categorias", "Gastos atípicos", "Transações"])

with tab1:
    if not res["recs"]:
        st.success("Nenhum alerta com os critérios atuais.")
    for r in res["recs"]:
        icon = {"alta": "🔴", "média": "🟠", "baixa": "🟡"}[r["severity"]]
        with st.container(border=True):
            st.markdown(f"**{icon} {r['title']}**")
            st.write(r["detail"])
            if r["monthly_saving"] > 0:
                st.caption(f"Economia potencial estimada (heurística): R$ {r['monthly_saving']:,.0f}/mês")
    if len(res["subs"]):
        st.subheader("Assinaturas recorrentes detectadas")
        st.dataframe(res["subs"].rename(columns={"servico": "Serviço", "valor_mensal": "Valor mensal (R$)", "meses": "Meses"}),
                     hide_index=True, width="stretch")

with tab2:
    m = res["monthly"].copy()
    m.index = m.index.astype(str)
    long = m.reset_index().melt(id_vars="m", var_name="Categoria", value_name="R$")
    st.plotly_chart(px.bar(long, x="m", y="R$", color="Categoria", title="Gasto mensal por categoria (previsto pelo modelo)",
                           labels={"m": "Mês"}), width="stretch")
    tot = long.groupby("Categoria")["R$"].sum().reset_index()
    st.plotly_chart(px.pie(tot, names="Categoria", values="R$", title="Composição do gasto no período"), width="stretch")

with tab3:
    a = d[(d.amount < 0) & (d.anom_flag == 1)].sort_values("anom_score", ascending=False)
    st.write(f"{len(a)} transações fora do padrão histórico **deste usuário**.")
    show = a[["date", "description", "amount", "category_pred", "anom_score", "dup"]].rename(columns={
        "date": "Data", "description": "Descrição", "amount": "Valor", "category_pred": "Categoria", "anom_score": "Escore", "dup": "Possível duplicidade"})
    st.dataframe(show, hide_index=True, width="stretch")
    st.caption("Atípico não significa errado: pode ser uma compra legítima rara. A decisão é sempre do usuário.")

with tab4:
    t = d[["date", "description", "amount", "category_pred", "confidence"]].rename(columns={
        "date": "Data", "description": "Descrição", "amount": "Valor", "category_pred": "Categoria prevista", "confidence": "Confiança"})
    st.dataframe(t, hide_index=True, width="stretch")
    st.download_button("Baixar CSV categorizado", t.to_csv(index=False).encode(), "extrato_categorizado.csv", "text/csv")
    low = (d.confidence < 0.5).sum()
    if low:
        st.warning(f"{low} transações com confiança < 50% — revise a categoria manualmente.")
