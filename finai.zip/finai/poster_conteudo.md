# Conteúdo do pôster (90×120 cm) — números reais de `results/metrics.json`

**Título:** FinIA: análise inteligente de hábitos financeiros pessoais com aprendizado de máquina
**Autores / Instituição:** [nomes] — Universidade Federal de Viçosa, campus Rio Paranaíba · SIN 323 (2026/2)

## 1. Introdução e motivação
Apps de controle financeiro mostram *o que* foi gasto, mas não apontam padrões, cobranças estranhas ou hábitos que crescem.
Categorizar manualmente centenas de linhas de extrato é a barreira de entrada. [Citar 1–2 fontes reais sobre endividamento/educação financeira no Brasil — a buscar; não inventar.]

## 2. Objetivo
PoC que, a partir de um CSV de extrato, (i) categoriza gastos, (ii) sinaliza gastos fora do padrão do próprio usuário e (iii) gera recomendações com economia estimada.

## 3. Metodologia
- Dados: 50 usuários sintéticos × 6 meses (≈11,2 mil despesas, 340 estabelecimentos), 5 arquétipos, anomalias e hábitos problemáticos rotulados.
- Classificação: TF-IDF de n-gramas + léxico + Regressão Logística; validação cruzada 5-fold **agrupada por estabelecimento**.
- Anomalias: Isolation Forest por usuário (features relativas ao histórico); baseline z-score robusto.
- Recomendação: regras sobre saídas dos modelos (limiares heurísticos).

## 4. Arquitetura (figura)
CSV → limpeza/normalização → **[IA 1] classificador** → **[IA 2] detector de anomalias** → regras → recomendações → app Streamlit

## 5. Resultados
| Classificação (estabelecimentos NOVOS) | Acurácia | F1 macro |
|---|---|---|
| Palavras-chave | 0,729 | 0,765 |
| Reg. Logística só n-gramas | 0,296 | 0,274 |
| **Híbrido (n-gramas + léxico)** | **0,744** | **0,744** |
| Híbrido, estabelecimentos já vistos | 0,979 | 0,974 |

Anomalias (4%): IF precisão 0,42 / revocação 0,55 / F1 0,48 / AP 0,58 vs. baseline F1 0,21 / AP 0,36. Revocação: duplicidade 0,80; novo estabelecimento 0,57; pico de valor 0,33.
Recomendações (problemas plantados): recall assinaturas 1,00; poupança 1,00; delivery em alta 0,80; atípicos 0,91.
Figuras: `results/matriz_confusao.png`, `results/curva_pr_anomalias.png`.

## 6. Discussão (limitações e riscos)
Dados sintéticos; léxico escrito pelos autores (otimista); regras ajustadas nos próprios dados; agrupamento sem resultado (ARI≈0,02);
falsos positivos de anomalia (precisão 0,42); privacidade/LGPD; recomendação não é aconselhamento financeiro; supervisão humana (usuário decide).

## 7. Conclusão
Classificação e detecção funcionam na PoC e superam baselines simples em dados sintéticos; falta validar com extratos reais e usuários. Trabalhos futuros: dataset real anonimizado, correção de categorias pelo usuário (aprendizado incremental), estudo com usuários.

## 8. Referências
[scikit-learn (Pedregosa et al., 2011); Liu, Ting & Zhou (2008), Isolation Forest; Streamlit; + fontes de motivação — conferir cada citação antes de imprimir.]
