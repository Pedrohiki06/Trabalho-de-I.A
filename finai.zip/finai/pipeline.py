"""Ponta a ponta: extrato (CSV) -> categorias -> anomalias -> recomendações."""
import io
import re
from pathlib import Path
import numpy as np
import pandas as pd
import categorizer, anomaly, recommender, data_gen

ROOT = Path(__file__).parent
MODEL_PATH = ROOT / "models" / "categorizer.joblib"
COLMAP = {"date": ["date", "data", "dt", "data lancamento"],
          "description": ["description", "descricao", "descrição", "historico", "histórico", "lancamento", "lançamento", "estabelecimento", "memo"],
          "amount": ["amount", "valor", "value", "quantia"]}


def _num(x):
    if isinstance(x, (int, float, np.number)):
        return float(x)
    s = str(x).strip().replace("R$", "").replace(" ", "")
    neg = s.startswith("-") or s.endswith("-") or (s.startswith("(") and s.endswith(")")) or s.upper().endswith("D")
    s = re.sub(r"[^0-9,.]", "", s)
    if "," in s:
        s = s.replace(".", "").replace(",", ".")
    v = float(s) if s else np.nan
    return -abs(v) if neg else v


def load_statement(src) -> pd.DataFrame:
    """Aceita caminho, bytes ou file-like. Colunas: data, descrição, valor (negativo = despesa)."""
    if isinstance(src, (str, Path)):
        raw = Path(src).read_bytes()
    elif hasattr(src, "read"):
        raw = src.read()
    else:
        raw = src
    text = raw.decode("utf-8-sig", errors="replace") if isinstance(raw, bytes) else raw
    df = pd.read_csv(io.StringIO(text), sep=None, engine="python")
    low = {c: str(c).strip().lower() for c in df.columns}
    rename = {}
    for std, alts in COLMAP.items():
        for c, l in low.items():
            if l in alts and std not in rename.values():
                rename[c] = std
                break
    df = df.rename(columns=rename)
    missing = {"date", "description", "amount"} - set(df.columns)
    if missing:
        raise ValueError(f"Colunas ausentes: {sorted(missing)}. Esperado: data, descrição, valor.")
    out = df[["date", "description", "amount"]].copy()
    iso = out["date"].astype(str).str.match(r"^\d{4}-\d{2}-\d{2}")
    out["date"] = pd.to_datetime(out["date"], format="ISO8601" if iso.all() else None, dayfirst=not iso.all(), errors="coerce")
    out["amount"] = out["amount"].map(_num)
    out = out.dropna(subset=["date", "amount"]).reset_index(drop=True)
    return out


def get_model(retrain=False):
    if MODEL_PATH.exists() and not retrain:
        return categorizer.load(MODEL_PATH)
    df = data_gen.generate()
    exp = df[df.amount < 0]
    m = categorizer.make_model("hibrido").fit(exp.description, exp.category)
    MODEL_PATH.parent.mkdir(exist_ok=True)
    categorizer.save(m, MODEL_PATH)
    return m


def run(df: pd.DataFrame, model=None, contamination=0.04):
    model = model or get_model()
    d = df.copy()
    d["category_pred"] = "Receita"
    mask = d.amount < 0
    if mask.any():
        proba = model.predict_proba(d.loc[mask, "description"])
        d.loc[mask, "category_pred"] = model.classes_[proba.argmax(1)]
        d.loc[mask, "confidence"] = proba.max(1)
    d.loc[~mask, "category_pred"] = "Receita"
    exp = anomaly.detect(d[mask], contamination=contamination)
    keep = ["anom_score", "anom_flag", "dup", "z_cat", "z_key", "ref_amount"]
    d = d.join(exp[keep], how="left")
    res = recommender.recommend(d)
    return dict(df=d, **res)
