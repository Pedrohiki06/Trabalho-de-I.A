# Resultados (dados sintéticos, seed=42)

## Classificação (validação cruzada 5-fold agrupada por estabelecimento)

| Modelo | Acurácia | F1 macro | Acurácia s/ Pix-pessoa |
|---|---|---|---|
| Palavras-chave (baseline) | 0.729 | 0.765 | 0.733 |
| Naive Bayes | 0.234 | 0.196 | 0.213 |
| Regressão Logística (n-gramas) | 0.296 | 0.274 | 0.279 |
| Híbrido (n-gramas + léxico + RL) | 0.744 | 0.744 | 0.750 |
| Híbrido — split ALEATÓRIO (estabelecimentos conhecidos) | 0.979 | 0.974 | 0.997 |

## Cenário 'conhecidos' — anomalias (por usuário)

| Contaminação | IF P | IF R | IF F1 | IF AP | Base P | Base R | Base F1 | Base AP |
|---|---|---|---|---|---|---|---|---|
| 0.02 | 0.55 | 0.38 | 0.45 | 0.58 | 0.25 | 0.19 | 0.21 | 0.36 |
| 0.04 | 0.42 | 0.55 | 0.48 | 0.58 | 0.25 | 0.19 | 0.21 | 0.36 |
| 0.06 | 0.34 | 0.65 | 0.45 | 0.58 | 0.25 | 0.19 | 0.21 | 0.36 |
| 0.08 | 0.28 | 0.72 | 0.41 | 0.58 | 0.25 | 0.19 | 0.21 | 0.36 |

Revocação por tipo (IF, 4%): {"duplicado": 0.8, "novo_estabelecimento": 0.57, "spike": 0.33}

### Cenário 'conhecidos' — recomendações vs. problemas plantados

| Problema | n | Recall | n (sem) | Falso alarme |
|---|---|---|---|---|
| delivery_alto_crescente | 10 | 0.80 | 40 | 0.03 |
| assinaturas_excesso | 10 | 1.00 | 40 | 0.00 |
| poupanca_baixa | 10 | 1.00 | 40 | 0.23 |
| gastos_atipicos | 44 | 0.91 | 6 | 0.50 |

Usuários 'equilibrado' com algum alerta: 0.80  [['excesso_categoria:Compras', 'gastos_atipicos:Geral', 'poupanca_baixa:Geral'], ['gastos_atipicos:Geral'], ['gastos_atipicos:Geral'], [], ['excesso_categoria:Compras', 'gastos_atipicos:Geral'], [], ['gastos_atipicos:Geral'], ['gastos_atipicos:Geral'], ['gastos_atipicos:Geral'], ['gastos_atipicos:Geral', 'poupanca_baixa:Geral']]

## Cenário 'novos' — anomalias (por usuário)

| Contaminação | IF P | IF R | IF F1 | IF AP | Base P | Base R | Base F1 | Base AP |
|---|---|---|---|---|---|---|---|---|
| 0.02 | 0.61 | 0.42 | 0.50 | 0.62 | 0.31 | 0.24 | 0.27 | 0.35 |
| 0.04 | 0.46 | 0.60 | 0.52 | 0.62 | 0.31 | 0.24 | 0.27 | 0.35 |
| 0.06 | 0.35 | 0.67 | 0.46 | 0.62 | 0.31 | 0.24 | 0.27 | 0.35 |
| 0.08 | 0.29 | 0.74 | 0.42 | 0.62 | 0.31 | 0.24 | 0.27 | 0.35 |

Revocação por tipo (IF, 4%): {"duplicado": 0.8, "novo_estabelecimento": 0.67, "spike": 0.37}

### Cenário 'novos' — recomendações vs. problemas plantados

| Problema | n | Recall | n (sem) | Falso alarme |
|---|---|---|---|---|
| delivery_alto_crescente | 10 | 0.60 | 40 | 0.12 |
| assinaturas_excesso | 10 | 0.90 | 40 | 0.00 |
| poupanca_baixa | 10 | 1.00 | 40 | 0.23 |
| gastos_atipicos | 44 | 0.98 | 6 | 0.50 |

Usuários 'equilibrado' com algum alerta: 0.80  [['gastos_atipicos:Geral', 'poupanca_baixa:Geral'], ['gastos_atipicos:Geral'], ['gastos_atipicos:Geral'], [], ['gastos_atipicos:Geral', 'tendencia_alta:Restaurantes e Delivery'], [], ['gastos_atipicos:Geral'], ['gastos_atipicos:Geral'], ['gastos_atipicos:Geral'], ['gastos_atipicos:Geral', 'poupanca_baixa:Geral', 'tendencia_alta:Compras']]

## Agrupamento: ARI=0.02, silhouette=0.26