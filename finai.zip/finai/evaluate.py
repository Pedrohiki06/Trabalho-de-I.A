"""Avaliação experimental da PoC. Executar: python evaluate.py  (gera results/metrics.json, figuras e resultados.md)"""
import json
import warnings
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans
from sklearn.metrics import (accuracy_score, f1_score, precision_recall_fscore_support, average_precision_score,
                             confusion_matrix, adjusted_rand_score, silhouette_score, precision_recall_curve,
                             classification_report)
from sklearn.model_selection import GroupKFold, StratifiedKFold, cross_val_predict
import categorizer, anomaly, recommender, data_gen

warnings.filterwarnings("ignore")
ROOT = Path(__file__).parent
RES = ROOT / "results"
RES.mkdir(exist_ok=True)
SEED = 42

df = data_gen.generate(n_per_arch=10, seed=SEED)
df.to_csv(ROOT / "data" / "extratos_sinteticos.csv", index=False)
exp_mask = df.amount < 0
exp = df[exp_mask].copy()
M = {}

# ---------------------------------------------------------------- 1. classificação
X = exp.description.to_numpy(dtype=object)
y = exp.category.to_numpy(dtype=object)
groups = exp.merchant.to_numpy(dtype=object)
gkf = GroupKFold(n_splits=5)
res = {}
res["Palavras-chave (baseline)"] = categorizer.KeywordBaseline().predict(X)
oof = {}
for name, kind in [("Naive Bayes", "nb"), ("Regressão Logística (n-gramas)", "lr"), ("Híbrido (n-gramas + léxico + RL)", "hibrido")]:
    oof[name] = cross_val_predict(categorizer.make_model(kind), X, y, groups=groups, cv=gkf)
    res[name] = oof[name]
rand_lr = cross_val_predict(categorizer.make_model("hibrido"), X, y,
                            cv=StratifiedKFold(5, shuffle=True, random_state=SEED))
pessoa = np.array([m.startswith("PESSOA_") for m in groups])
M["classificacao"] = {}
for k, p in res.items():
    M["classificacao"][k] = dict(acuracia=accuracy_score(y, p), f1_macro=f1_score(y, p, average="macro"),
                                 acuracia_sem_pix_pessoa=accuracy_score(y[~pessoa], p[~pessoa]))
M["classificacao"]["Híbrido — split ALEATÓRIO (estabelecimentos conhecidos)"] = dict(
    acuracia=accuracy_score(y, rand_lr), f1_macro=f1_score(y, rand_lr, average="macro"),
    acuracia_sem_pix_pessoa=accuracy_score(y[~pessoa], rand_lr[~pessoa]))
M["classificacao_info"] = dict(n_transacoes=int(len(exp)), n_estabelecimentos=int(exp.merchant.nunique()),
                               frac_pix_pessoa=float(pessoa.mean()))
best = "Híbrido (n-gramas + léxico + RL)"
lr_pred = oof[best]
exp["category_pred"] = lr_pred
report = classification_report(y, lr_pred, output_dict=True, zero_division=0)
M["classificacao_por_classe_LR"] = {c: {k: round(v, 3) for k, v in report[c].items()} for c in data_gen.CATEGORIAS}

labels = data_gen.CATEGORIAS
cm = confusion_matrix(y, lr_pred, labels=labels, normalize="true")
fig, ax = plt.subplots(figsize=(8, 6.5))
im = ax.imshow(cm, cmap="Blues", vmin=0, vmax=1)
ax.set_xticks(range(len(labels)), labels, rotation=45, ha="right", fontsize=8)
ax.set_yticks(range(len(labels)), labels, fontsize=8)
for i in range(len(labels)):
    for j in range(len(labels)):
        ax.text(j, i, f"{cm[i, j]:.2f}", ha="center", va="center", fontsize=7, color="white" if cm[i, j] > .5 else "black")
ax.set_xlabel("Previsto"); ax.set_ylabel("Verdadeiro")
ax.set_title("Matriz de confusão normalizada — Modelo híbrido\n(validação cruzada agrupada por estabelecimento)")
fig.tight_layout(); fig.savefig(RES / "matriz_confusao.png", dpi=200); plt.close(fig)

# ---------------------------------------------------------------- 2/3. anomalias + recomendações, em 2 cenários
# Cenário "conhecidos": categorias previstas com split aleatório (estabelecimentos já vistos no treino) -> otimista
# Cenário "novos": categorias previstas com split agrupado (estabelecimentos nunca vistos) -> pessimista
PLANT = {
    "delivery_alto_crescente": lambda rs: any(r["code"] in ("tendencia_alta", "excesso_categoria") and r["category"] == "Restaurantes e Delivery" for r in rs),
    "assinaturas_excesso": lambda rs: any(r["code"] == "assinaturas_excesso" for r in rs),
    "poupanca_baixa": lambda rs: any(r["code"] == "poupanca_baixa" for r in rs),
    "gastos_atipicos": lambda rs: any(r["code"] == "gastos_atipicos" for r in rs),
}
arch = df.groupby("user_id").archetype.first()
planted = {u: [p for p in data_gen.ARCH[a]["planted"] if p != "gastos_atipicos"] for u, a in arch.items()}
# verdade-terreno de "gastos atípicos": impacto REAL injetado >= limiar de materialidade do recomendador
_e = df[df.amount < 0]
for u, g in _e.groupby("user_id"):
    if g.excess.sum() / 6 >= recommender.ANOM_IMPACT_ALERT * (g.amount.abs().sum() / 6):
        planted[u].append("gastos_atipicos")
M["cenarios"] = {}
per_user_main = None


def scenario(name, cat_pred):
    global per_user_main
    base_df = df.copy()
    base_df["category_pred"] = "Receita"
    base_df.loc[exp.index, "category_pred"] = cat_pred
    rows, per_user, types = [], {}, {}
    for contam in [0.02, 0.04, 0.06, 0.08]:
        yt, yp, yb, aps, apb = [], [], [], [], []
        for uid, g in base_df[base_df.amount < 0].groupby("user_id"):
            d = anomaly.detect(g, contamination=contam)
            base = anomaly.zscore_baseline(d)
            yt.append(d.is_anomaly.values); yp.append(d.anom_flag.values); yb.append(base.values)
            if d.is_anomaly.sum() > 0:
                aps.append(average_precision_score(d.is_anomaly, d.anom_score))
                apb.append(average_precision_score(d.is_anomaly, d.z_cat.clip(lower=-5)))
            if contam == 0.04:
                per_user[uid] = d
                for t, gg in d[d.is_anomaly == 1].groupby("anomaly_type"):
                    types.setdefault(t, []).append(gg.anom_flag.values)
        yt, yp, yb = map(np.concatenate, (yt, yp, yb))
        pi, ri, fi, _ = precision_recall_fscore_support(yt, yp, average="binary", zero_division=0)
        pb, rb, fb, _ = precision_recall_fscore_support(yt, yb, average="binary", zero_division=0)
        rows.append(dict(contaminacao=contam, IF_precisao=pi, IF_revocacao=ri, IF_f1=fi, IF_AP_medio=float(np.mean(aps)),
                         base_precisao=pb, base_revocacao=rb, base_f1=fb, base_AP_medio=float(np.mean(apb))))
    out = dict(anomalias=rows, anomalia_recall_por_tipo_IF={t: float(np.concatenate(v).mean()) for t, v in types.items()})
    recs_user = {}
    for uid, g in base_df.groupby("user_id"):
        d = g.join(per_user[uid][["anom_score", "anom_flag", "dup", "z_cat", "z_key", "ref_amount"]], how="left")
        recs_user[uid] = recommender.recommend(d)["recs"]
    tab = {}
    for issue, fn in PLANT.items():
        has = [u for u in arch.index if issue in planted[u]]
        no = [u for u in arch.index if issue not in planted[u]]
        tab[issue] = dict(n_com_problema=len(has), recall=float(np.mean([fn(recs_user[u]) for u in has])),
                          n_sem_problema=len(no), falso_alarme=float(np.mean([fn(recs_user[u]) for u in no])))
    ctrl = [u for u in arch.index if arch[u] == "equilibrado"]
    out["recomendacao"] = tab
    out["controle_algum_alerta"] = float(np.mean([len(recs_user[u]) > 0 for u in ctrl]))
    out["codigos_controle"] = [sorted({r["code"] + ":" + r["category"] for r in recs_user[u]}) for u in ctrl]
    M["cenarios"][name] = out
    if name == "conhecidos":
        per_user_main = per_user


scenario("conhecidos", rand_lr)
scenario("novos", lr_pred)
M["anomalias_info"] = dict(n_anomalias=int(df.is_anomaly.sum()), frac=float(df[df.amount < 0].is_anomaly.mean()))

# curva PR (cenário conhecidos; pontuação -> percentil por usuário)
fig, ax = plt.subplots(figsize=(5.5, 4.5))
allx = pd.concat([d.assign(user_id=u) for u, d in per_user_main.items()])
for col, lab in [("anom_score", "Isolation Forest (por usuário)"), ("z_cat", "Baseline: z-score robusto")]:
    s = allx.groupby("user_id")[col].rank(pct=True)
    p, r, _ = precision_recall_curve(allx.is_anomaly, s)
    ax.plot(r, p, label=f"{lab} (AP={average_precision_score(allx.is_anomaly, s):.2f})")
ax.set_xlabel("Revocação"); ax.set_ylabel("Precisão"); ax.set_title("Detecção de anomalias — Precisão x Revocação")
ax.legend(fontsize=8); ax.grid(alpha=.3); fig.tight_layout(); fig.savefig(RES / "curva_pr_anomalias.png", dpi=200); plt.close(fig)

# ---------------------------------------------------------------- 4. agrupamento (perfis de consumo)
e = exp.copy()
e["m"] = e.date.dt.to_period("M")
sh = e.pivot_table(index=["user_id", "m"], columns="category_pred", values="amount", aggfunc=lambda x: x.abs().sum(), fill_value=0)
sh = sh.div(sh.sum(1), axis=0)
km = KMeans(n_clusters=5, n_init=20, random_state=SEED).fit(sh.values)
truth = arch.loc[sh.index.get_level_values(0)].values
M["agrupamento"] = dict(ARI_vs_arquetipo=float(adjusted_rand_score(truth, km.labels_)),
                        silhouette=float(silhouette_score(sh.values, km.labels_)), n_user_meses=int(len(sh)))

json.dump(M, open(RES / "metrics.json", "w"), indent=2, ensure_ascii=False, default=float)

# ---------------------------------------------------------------- resumo em markdown
L = ["# Resultados (dados sintéticos, seed=42)\n", "## Classificação (validação cruzada 5-fold agrupada por estabelecimento)\n",
     "| Modelo | Acurácia | F1 macro | Acurácia s/ Pix-pessoa |", "|---|---|---|---|"]
for k, v in M["classificacao"].items():
    L.append(f"| {k} | {v['acuracia']:.3f} | {v['f1_macro']:.3f} | {v['acuracia_sem_pix_pessoa']:.3f} |")
for sc, o in M["cenarios"].items():
    L += [f"\n## Cenário '{sc}' — anomalias (por usuário)\n", "| Contaminação | IF P | IF R | IF F1 | IF AP | Base P | Base R | Base F1 | Base AP |", "|---|---|---|---|---|---|---|---|---|"]
    for r in o["anomalias"]:
        L.append(f"| {r['contaminacao']} | {r['IF_precisao']:.2f} | {r['IF_revocacao']:.2f} | {r['IF_f1']:.2f} | {r['IF_AP_medio']:.2f} | {r['base_precisao']:.2f} | {r['base_revocacao']:.2f} | {r['base_f1']:.2f} | {r['base_AP_medio']:.2f} |")
    L.append("\nRevocação por tipo (IF, 4%): " + json.dumps({k: round(v, 2) for k, v in o["anomalia_recall_por_tipo_IF"].items()}, ensure_ascii=False))
    L += [f"\n### Cenário '{sc}' — recomendações vs. problemas plantados\n", "| Problema | n | Recall | n (sem) | Falso alarme |", "|---|---|---|---|---|"]
    for k, v in o["recomendacao"].items():
        L.append(f"| {k} | {v['n_com_problema']} | {v['recall']:.2f} | {v['n_sem_problema']} | {v['falso_alarme']:.2f} |")
    L.append(f"\nUsuários 'equilibrado' com algum alerta: {o['controle_algum_alerta']:.2f}  {o['codigos_controle']}")
L.append(f"\n## Agrupamento: ARI={M['agrupamento']['ARI_vs_arquetipo']:.2f}, silhouette={M['agrupamento']['silhouette']:.2f}")
(RES / "resultados.md").write_text("\n".join(L), encoding="utf-8")
print("\n".join(L))
