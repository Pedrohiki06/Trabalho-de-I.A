# FinIA — Análise inteligente de hábitos financeiros (PoC · SIN 323 · UFV 2026/2)

Importa um extrato (CSV) → **classifica** cada gasto → **detecta gastos atípicos** em relação ao histórico do próprio usuário
→ **recomenda** ações (com economia estimada). Tudo local, sem integração bancária.

## Como executar
```bash
pip install -r requirements.txt
python data_gen.py          # gera data/extratos_sinteticos.csv e data/exemplo_extrato.csv
streamlit run app.py        # demo (usa o extrato de exemplo ou o seu CSV)
python evaluate.py          # reproduz TODOS os números do pôster (~4 min) -> results/
python tests/test_app.py    # teste headless do app
```
Formato do CSV: `data, descrição, valor` (valor negativo = despesa). Aceita `;`/`,` e números como `1.234,56`.

## Arquitetura
| Módulo | Papel da IA |
|---|---|
| `categorizer.py` | Reg. Logística sobre TF-IDF de n-gramas de caracteres + léxico de palavras genéricas (modelo **híbrido**). Baselines: palavras-chave e Naive Bayes |
| `anomaly.py` | Isolation Forest **por usuário** sobre features relativas ao histórico (z robusto por estabelecimento/categoria, duplicidade, intervalo). Baseline: z-score |
| `recommender.py` | Regras explícitas sobre as saídas dos modelos (categorias, anomalias, recorrência). **Não é aprendizado de máquina** — ver limitações |
| `pipeline.py` / `app.py` | Orquestração e interface (Streamlit) |

## Limitações que a banca vai perguntar
1. **Dados sintéticos**: todos os números vêm de um gerador escrito por nós. Medem se o código funciona, não se funciona no mundo real.
2. **Estabelecimentos novos**: com split agrupado por estabelecimento, o classificador só n-gramas cai para ~0,30 de acurácia; o híbrido
   chega a ~0,74 graças ao léxico (escrito por nós, conhecendo o domínio → otimista). Com estabelecimentos já vistos: ~0,98.
3. **Recomendador por regras**: limiares (10% poupança, 12%/10% da renda, ≥6 assinaturas, 4% de impacto) são heurísticas, ajustadas
   olhando os dados sintéticos. Economia estimada = ordem de grandeza.
4. **Agrupamento (KMeans)**: não recuperou os perfis do gerador (ARI≈0,02); está fora do app. Reportado como resultado negativo.
5. **Anomalia ≠ erro**: precisão ≈0,42 a 4% de contaminação; spikes têm revocação baixa (~0,33).
6. **Privacidade (LGPD)**: extratos são dados pessoais financeiros; a PoC processa localmente e não persiste o upload.
